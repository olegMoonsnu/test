
'use strict';
const services=[
 {id:'access',group:'Доступы',name:'Доступ к приложению',desc:'Подключение к корпоративной системе',code:'ID'},
 {id:'network',group:'Связь',name:'Подключение к VPN',desc:'Помощь с удалённым доступом к сети',code:'VPN'},
 {id:'device',group:'Техника',name:'Выдача оборудования',desc:'Монитор, гарнитура или рабочий ноутбук',code:'HW'},
 {id:'mail',group:'Связь',name:'Корпоративная почта',desc:'Вопросы о почтовом ящике и рассылках',code:'@'},
 {id:'program',group:'Доступы',name:'Установка программы',desc:'Установка приложения на рабочий компьютер',code:'APP'},
 {id:'repair',group:'Техника',name:'Ремонт рабочего места',desc:'Диагностика неисправного устройства',code:'IT'}];
const app=document.getElementById('app'), statuses=['Новая','В работе','Решена'];
const tickets=[];let next=1043,group='Все',query='',filter='Все';
const stamp=()=>new Date().toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});
function seed(id,service,title,state,body){tickets.push({id,service,title,state,body,importance:'Обычная',events:[{who:'Система',time:'Демо',msg:'Заявка зарегистрирована.'},...(state? [{who:'Служба поддержки',time:'Демо',msg:state===1?'Заявка принята в работу.':'Работы завершены.'}] :[])]});}
seed(1042,'network','Не подключается VPN',1,'При подключении к рабочей сети появляется ошибка соединения.');
seed(1041,'device','Дополнительный монитор',2,'Нужен второй монитор для рабочего места.');
function el(tag,text,cls){const e=document.createElement(tag);if(text!=null)e.textContent=text;if(cls)e.className=cls;return e}
function btn(text,fn,cls='secondary'){const b=el('button',text,cls);b.type='button';b.onclick=fn;return b}
function go(path){if(location.hash==='#'+path)render();else location.hash=path}
function note(text){document.getElementById('notice').textContent=text}
function badge(t){return el('span',statuses[t.state],'status '+['','work','done'][t.state])}
function ticket(t){const b=btn('',()=>go('ticket/'+t.id),'ticket');b.append(el('small','№ '+t.id),el('b',t.title),badge(t));return b}
function box(title){const b=el('section',null,'box');if(title)b.append(el('h2',title));return b}
function labeled(form,title,input,id){const label=el('label',title);input.id=id;label.htmlFor=id;form.append(label,input)}
function hero(title,desc){const h=el('section',null,'hero'),wrap=el('div');wrap.append(el('h1',title),el('p',desc));const motif=el('div',null,'motif');motif.setAttribute('aria-hidden','true');h.append(wrap,motif);return h}
function catalog(){
 app.append(hero('Чем вам помочь?','Выберите услугу, чтобы обратиться в службу поддержки.'));
 const layout=el('div',null,'layout'),left=el('section'),aside=el('aside',null,'box aside');layout.append(left,aside);app.append(layout);
 const search=el('input');search.type='search';search.placeholder='Найти услугу';search.setAttribute('aria-label','Найти услугу');search.value=query;
 const chips=el('div',null,'tools'),cards=el('div',null,'cards');left.append(el('h2','Каталог услуг'),search,chips,cards);
 function draw(){cards.replaceChildren();const matches=services.filter(s=>(group==='Все'||s.group===group)&&(s.name+' '+s.group+' '+s.desc).toLowerCase().includes(query.trim().toLowerCase()));
 for(const s of matches){const b=btn('',()=>go('new/'+s.id),'card');b.append(el('span',s.code,'glyph'),el('b',s.name),el('small',s.desc));cards.append(b)}
 if(!matches.length)cards.append(el('p','Подходящих услуг нет. Измените запрос или категорию.','empty'));
 for(const chip of chips.children)chip.setAttribute('aria-pressed',String(chip.textContent===group));}
 for(const g of ['Все','Доступы','Связь','Техника'])chips.append(btn(g,()=>{group=g;draw()},'chip'));
 search.oninput=()=>{query=search.value;draw()};draw();
 aside.append(el('h2','Последние заявки'));tickets.slice().sort((a,b)=>b.id-a.id).slice(0,3).forEach(t=>aside.append(ticket(t)));aside.append(btn('Все мои заявки',()=>go('tickets'),'link'));
}
function list(){app.append(hero('Мои заявки','Откройте обращение, чтобы посмотреть историю и добавить комментарий.'));
 const chips=el('div',null,'tools'),items=el('section');app.append(chips,items);
 function draw(){items.replaceChildren();for(const t of tickets.slice().sort((a,b)=>b.id-a.id))if(filter==='Все'||statuses[t.state]===filter)items.append(ticket(t));if(!items.childElementCount)items.append(el('p','Заявок с таким статусом пока нет.','empty'));for(const b of chips.children)b.setAttribute('aria-pressed',String(b.textContent===filter))}
 for(const s of ['Все',...statuses])chips.append(btn(s,()=>{filter=s;draw()},'chip'));draw()
}
function request(s){const w=el('div',null,'narrow');app.append(w);w.append(btn('В каталог услуг',()=>go('catalog'),'back'),el('h1',s.name));
 const f=el('form',null,'box'),title=el('input'),body=el('textarea'),importance=el('select');title.required=body.required=true;title.maxLength=100;body.maxLength=2000;
 title.placeholder='Кратко опишите задачу';body.placeholder='Что требуется сделать?';for(const val of ['Обычная','Высокая'])importance.append(el('option',val));labeled(f,'Тема заявки',title,'subject');labeled(f,'Описание',body,'description');labeled(f,'Важность',importance,'priority');
 const send=el('button','Отправить заявку','primary');send.type='submit';const actions=el('div',null,'actions');actions.append(send,btn('Отмена',()=>go('catalog')));f.append(actions);w.append(f);
 f.onsubmit=e=>{e.preventDefault();for(const field of [title,body]){if(!field.value.trim()){field.setCustomValidity('Введите текст.');field.reportValidity();return}}const t={id:next++,service:s.id,title:title.value.trim(),body:body.value.trim(),importance:importance.value,state:0,events:[{who:'Система',time:stamp(),msg:'Заявка зарегистрирована.'}]};tickets.unshift(t);filter='Все';note('Заявка № '+t.id+' создана');go('ticket/'+t.id)};for(const field of [title,body])field.oninput=()=>field.setCustomValidity('')
}
function detail(t){const w=el('div',null,'narrow');app.append(w);w.append(btn('К моим заявкам',()=>go('tickets'),'back'));const meta=el('div',null,'summary');meta.append(el('small','Заявка № '+t.id),badge(t));w.append(meta,el('h1',t.title));
 const info=box('Описание');info.append(el('p',t.body,'bodytext'),el('small',services.find(s=>s.id===t.service).name+' · Важность: '+t.importance));w.append(info);
 const history=box('История заявки');w.append(history);for(const ev of t.events){const e=el('div',null,'entry');e.append(el('strong',ev.who),el('small',' · '+ev.time),el('p',ev.msg));history.append(e)}
 const f=el('form'),comment=el('textarea');comment.maxLength=1500;comment.required=true;labeled(f,'Комментарий',comment,'comment');const send=el('button','Добавить комментарий','primary');send.type='submit';const actions=el('div',null,'actions');actions.append(send);f.append(actions);history.append(f);
 f.onsubmit=e=>{e.preventDefault();if(!comment.value.trim()){comment.setCustomValidity('Введите текст.');comment.reportValidity();return}t.events.push({who:'Вы',time:stamp(),msg:comment.value.trim()});note('Комментарий добавлен');render();document.getElementById('comment').focus()};comment.oninput=()=>comment.setCustomValidity('');
 const sim=box('Действие специалиста');sim.append(el('p','В демо вы можете проверить следующий этап обработки заявки.','muted'));
 const labels=['Принять в работу','Отметить решённой','Вернуть в работу'];sim.append(btn(labels[t.state],()=>{t.state=t.state===1?2:1;t.events.push({who:'Демо-специалист',time:stamp(),msg:'Статус изменён: '+statuses[t.state]+'.'});note('Статус: '+statuses[t.state]);render()}));w.append(sim)
}
function render(){const [p,id]=location.hash.slice(1).split('/');app.replaceChildren();const t=tickets.find(x=>String(x.id)===id),s=services.find(x=>x.id===id);
 const inTickets=p==='tickets'||(p==='ticket'&&t);document.getElementById('catalogNav').setAttribute('aria-current',inTickets?'false':'page');document.getElementById('ticketsNav').setAttribute('aria-current',inTickets?'page':'false');
 if(p==='new'&&s)request(s);else if(p==='ticket'&&t)detail(t);else if(p==='tickets'||p==='ticket')list();else catalog();window.scrollTo(0,0)}
document.getElementById('catalogNav').onclick=()=>go('catalog');document.getElementById('ticketsNav').onclick=()=>go('tickets');window.addEventListener('hashchange',()=>{render();app.focus({preventScroll:true})});render();
